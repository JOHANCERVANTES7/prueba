package com.example.ex

 data class User(
    var id: Int = -1,
    var username: String = "",
    var email: String = "",
    var password: String =""
 )