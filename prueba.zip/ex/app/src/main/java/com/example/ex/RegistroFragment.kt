package com.example.ex

import android.os.Bundle
import android.renderscript.ScriptGroup.Binding
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import com.example.ex.databinding.FragmentRegistroBinding


// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [RegistroFragment.newInstance] factory method to
 * create an instance of this fragment
 */
class RegistroFragment : Fragment() {
    private lateinit var binding: FragmentRegistroBinding
    private lateinit var db: DatabaseHelper

    private var param1: String? = null
    private var param2: String? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentRegistroBinding.inflate(inflater, container, false)
        return binding.root
        db = DatabaseHelper(requireContext())
        binding.BtnRegistrate.setOnClickListener{
            registerUser()
        }
    }

private fun registerUser() {
    val username = binding.textInputUsername.text.toString()
    val email = binding.textInputEmail.text.toString()
    val password = binding.textInputPassword.text.toString()

    if (ValidationUtils.isTextNotEmpty(username) &&
        ValidationUtils.isTextNotEmpty(email) &&
        ValidationUtils.isTextNotEmpty(password)
    ) {
        if(ValidationUtils.isValidEmail(email)){
            val user = User(username = username, email = email.trim(), password = password)
            db.registerUser(user)
            Toast.makeText(context, "Usuario Registrado", Toast.LENGTH_SHORT).show()
        }else{
            Toast.makeText(context, "formato invalido de Email",Toast.LENGTH_SHORT).show()
        }
    }else{
        Toast.makeText(context,"porfavor complete todos los campos", Toast.LENGTH_SHORT).show()
    }
}
    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment RegistroFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            RegistroFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}